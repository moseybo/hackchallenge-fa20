//
//  ViewController.swift
//  Object Detection V1
//
//  Created by Raleigh Clemens on 12/5/20.
//

import UIKit

class ViewController: UIViewController {
    
    var loginB: UIButton!
    var register: UIButton!
    var see: UIButton!
    var usernameTF: UITextField!
    var pswdTF: UITextField!
    var count: Int! = 0
    
    var thisUserSessionToken: String!
    var yellow = UIColor(red: 252/255, green: 208/255, blue: 31/255, alpha: 1)
    
    var toHome: UIButton!
    
    var iUsername = "Email...                              "
    var iPswd = "Password...                       "
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Login"
        navigationController?.navigationBar.barTintColor = yellow
        setUpViews()
        setUpConstraints()
        
    }

    func setUpViews(){
        loginB = UIButton()
        loginB.translatesAutoresizingMaskIntoConstraints = false
        loginB.setTitle(" Login ", for: .normal)
        loginB.setTitleColor(.white, for: .normal)
        loginB.layer.borderWidth = 0.9
        loginB.layer.borderColor = (UIColor( red: 0.5, green: 0.5, blue:0, alpha: 1.0 )).cgColor
        loginB.addTarget(self, action: #selector(login), for: .touchUpInside)
        view.addSubview(loginB)
        
        see = UIButton()
        see.translatesAutoresizingMaskIntoConstraints = false
        see.setTitleColor(.white, for: .normal)
        see.backgroundColor = .gray
        see.layer.borderWidth = 0.9
        see.layer.borderColor = (UIColor( red: 0.5, green: 0.5, blue:0, alpha: 1.0 )).cgColor
        see.addTarget(self, action: #selector(seeIt), for: .touchUpInside)
        see.setImage(UIImage(named: "eye"), for: .normal)
        view.addSubview(see)
        
        register = UIButton()
        register.translatesAutoresizingMaskIntoConstraints = false
        register.setTitle(" Register ", for: .normal)
        register.titleLabel?.font = UIFont.boldSystemFont(ofSize: 22)
        register.layer.borderWidth = 1.9
        register.layer.borderColor = (UIColor( red: 0.5, green: 0.5, blue:0, alpha: 1.0 )).cgColor
        register.setTitleColor(.white, for: .normal)
        register.layer.cornerRadius = 10
        register.addTarget(self, action: #selector(registrate), for: .touchUpInside)
        view.addSubview(register)
        
        usernameTF = UITextField()
        usernameTF.attributedPlaceholder =
            NSAttributedString(string: iUsername, attributes: [NSAttributedString.Key.foregroundColor : yellow])
        usernameTF.translatesAutoresizingMaskIntoConstraints = false
        usernameTF.backgroundColor = .gray
        usernameTF.clearsOnBeginEditing = true
        usernameTF.autocapitalizationType = .none
        usernameTF.autocorrectionType = .no
        usernameTF.spellCheckingType = .no
        view.addSubview(usernameTF)
        
        pswdTF = UITextField()
        pswdTF.attributedPlaceholder =
            NSAttributedString(string: iPswd, attributes: [NSAttributedString.Key.foregroundColor : yellow])
        pswdTF.translatesAutoresizingMaskIntoConstraints = false
        pswdTF.backgroundColor = .gray
        pswdTF.clearsOnBeginEditing = true
        pswdTF.isSecureTextEntry = true
        pswdTF.autocapitalizationType = .none
        pswdTF.autocorrectionType = .no
        pswdTF.spellCheckingType = .no
        view.addSubview(pswdTF)
        
        toHome = UIButton()
        toHome.translatesAutoresizingMaskIntoConstraints = false
        toHome.setTitle(" Home ", for: .normal)
        toHome.setTitleColor(.white, for: .normal)
        toHome.layer.borderWidth = 1.9
        toHome.layer.borderColor = (UIColor( red: 0.5, green: 0.5, blue:0, alpha: 1.0 )).cgColor
        toHome.addTarget(self, action: #selector(goHome), for: .touchUpInside)
        view.addSubview(toHome)
    
        
        
    }

    
    @objc func seeIt(){
        if(pswdTF.isSecureTextEntry){
            pswdTF.isSecureTextEntry = false
        }
        else{
            pswdTF.isSecureTextEntry = true
        }
    }
    
    @objc func goHome(){
        navigationController?.pushViewController(HomeViewController(), animated: true)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            register.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            register.topAnchor.constraint(equalTo: view.topAnchor, constant: 120),
            register.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -740),
            
            
            usernameTF.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            usernameTF.topAnchor.constraint(equalTo: view.topAnchor, constant: 300),
            usernameTF.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -570),
            //usernameTF.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            
            pswdTF.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            pswdTF.topAnchor.constraint(equalTo: usernameTF.bottomAnchor, constant: 15),
            pswdTF.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -530),
            
            see.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 315),
            see.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -70),
            see.topAnchor.constraint(equalTo: usernameTF.bottomAnchor, constant: 15),
            see.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -530),
            
            loginB.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loginB.topAnchor.constraint(equalTo: pswdTF.bottomAnchor, constant: 15),
            loginB.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -500),
            
            toHome.centerXAnchor.constraint(equalTo:view.centerXAnchor),
            toHome.topAnchor.constraint(equalTo: view.topAnchor, constant: 800),
            toHome.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -60)
            
            
        ])
    }
    
    


    @objc func login(){
        if(usernameTF.text?.count == 0 || pswdTF.text?.count == 0){
            return
        }
        else{
            NetworkManager.postLogin(em: usernameTF.text!, ps: pswdTF.text!) {token1 in
                self.thisUserSessionToken = token1
                
                print("us: " + self.usernameTF.text!)
                print("ps: " + self.pswdTF.text!)
                
                if(self.thisUserSessionToken == "failure"){
                    let alert = UIAlertController(title: "Alert", message: "This email address is not currently registered, or the password is incorrect.", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                else{
                    self.navigationController?.pushViewController(HomeViewController(), animated: true)
                }
            }
        }
        
        print("pressed")
        
    }
    
    @objc func registrate(){
        navigationController?.pushViewController(RegistrateViewController(), animated: true)
    }
    
}
