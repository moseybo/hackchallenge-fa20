//
//  FilterBarCell.swift
//  Object Detection V1
//
//  Created by Raleigh Clemens on 12/9/20.
//

import UIKit

class FilterBarCell: UICollectionViewCell {
    private var filterLabel: UILabel!
    private var containerView: UIView!
    
    let lightBlue = UIColor(red: CGFloat(0), green: CGFloat(0.6627), blue: CGFloat(0.902), alpha: CGFloat(1))
    
    let lightgray = UIColor(red: CGFloat(0.898), green: CGFloat(0.898), blue: CGFloat(0.8627), alpha: CGFloat(0.75))
    
    //private var gamePlay: UIImageView!
    
    override init(frame: CGRect){
        super.init(frame: frame)
        
        setUpViews()
        setUpConstraints()
        
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    func setUpViews(){
        containerView = UIView()
        containerView.layer.cornerRadius = 15
        containerView.layer.backgroundColor = UIColor.white.cgColor
        containerView.clipsToBounds = true
        containerView.layer.masksToBounds = true
        containerView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(containerView)
        
        filterLabel = UILabel()
        filterLabel.textColor = lightBlue
        filterLabel.layer.cornerRadius = 10.0
        filterLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(filterLabel)
        
    }
        
    
    func setUpConstraints(){
        let containerPadding: CGFloat = 2
        
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: containerPadding),
            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: containerPadding),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -containerPadding),
            
            filterLabel.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            filterLabel.centerYAnchor.constraint(equalTo: containerView.centerYAnchor),

            
        ])
    }
    
    func configure(filter: Filter, filterList: [Filter]){
        filterLabel.text = filter.title
        if(filterList.contains(filter)){
            //print("filter is selected")
            filterLabel.textColor = lightgray
            containerView.backgroundColor = lightBlue
        }
        else{
            //print("filter is not selected")
            filterLabel.textColor = lightBlue
            containerView.backgroundColor = lightgray
        
        }
    }
    
    
    
}
