//
//  RegistrateViewController.swift
//  Object Detection V1
//
//  Created by Raleigh Clemens on 12/14/20.
//

import UIKit

class RegistrateViewController: UIViewController {

    var register: UIButton!
    
    var nameL: UILabel!
    var nameTF: UITextField!
    var emailL: UILabel!
    var emailTF: UITextField!
    var usernameL: UILabel!
    var usernameTF: UITextField!
    var pswdL: UILabel!
    var pswdTF: UITextField!
    var confirmPswdL: UILabel!
    var confirmPswdTF: UITextField!
    
    var thisUserSessionToken: String!
    
    
    var iUsername = "Username...         "
    var iPswd = "Password...          "
    var iEmail = "Email...                  "
    var iName = "Name...                 "
    
    let yellow = UIColor(red: 252/255, green: 208/255, blue: 31/255, alpha: 1)

    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Login"
        navigationController?.navigationBar.barTintColor = yellow

        setUpViews()
        setUpConstraints()
        
    }

    func setUpViews(){
        register = UIButton()
        register.translatesAutoresizingMaskIntoConstraints = false
        register.setTitle(" Register ", for: .normal)
        register.layer.borderWidth = 0.9
        register.layer.borderColor = (UIColor( red: 0.5, green: 0.5, blue:0, alpha: 1.0 )).cgColor
        register.setTitleColor(.white, for: .normal)
        register.layer.cornerRadius = 10
        register.addTarget(self, action: #selector(registrate), for: .touchUpInside)
        view.addSubview(register)
        
        nameTF = UITextField()
        nameTF.attributedPlaceholder =
            NSAttributedString(string: iName, attributes: [NSAttributedString.Key.foregroundColor : yellow])
        nameTF.translatesAutoresizingMaskIntoConstraints = false
        nameTF.backgroundColor = .gray
        nameTF.clearsOnBeginEditing = true
        nameTF.autocorrectionType = .no
        nameTF.spellCheckingType = .no
        view.addSubview(nameTF)
        
        nameL = UILabel()
        nameL.text = "Name:"
        nameL.textColor = .gray
        nameL.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameL)
        
        emailTF = UITextField()
        emailTF.attributedPlaceholder =
            NSAttributedString(string: iEmail, attributes: [NSAttributedString.Key.foregroundColor : yellow])
        emailTF.translatesAutoresizingMaskIntoConstraints = false
        emailTF.backgroundColor = .gray
        emailTF.clearsOnBeginEditing = true
        emailTF.autocapitalizationType = .none
        emailTF.autocorrectionType = .no
        emailTF.spellCheckingType = .no
        view.addSubview(emailTF)
        
        emailL = UILabel()
        emailL.text = "Email:"
        emailL.textColor = .gray
        emailL.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(emailL)
        
        usernameTF = UITextField()
        usernameTF.attributedPlaceholder =
            NSAttributedString(string: iUsername, attributes: [NSAttributedString.Key.foregroundColor : yellow])
        usernameTF.translatesAutoresizingMaskIntoConstraints = false
        usernameTF.backgroundColor = .gray
        usernameTF.clearsOnBeginEditing = true
        usernameTF.autocapitalizationType = .none
        usernameTF.autocorrectionType = .no
        usernameTF.spellCheckingType = .no
        view.addSubview(usernameTF)
        
        usernameL = UILabel()
        usernameL.text = "Username:"
        usernameL.textColor = .gray
        usernameL.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(usernameL)

        pswdL = UILabel()
        pswdL.text = "Password:"
        pswdL.textColor = .gray
        pswdL.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(pswdL)

        pswdTF = UITextField()
        pswdTF.attributedPlaceholder =
            NSAttributedString(string: iPswd, attributes: [NSAttributedString.Key.foregroundColor : yellow])
        pswdTF.translatesAutoresizingMaskIntoConstraints = false
        pswdTF.backgroundColor = .gray
        pswdTF.clearsOnBeginEditing = true
        pswdTF.autocapitalizationType = .none
        pswdTF.autocorrectionType = .no
        pswdTF.spellCheckingType = .no
        view.addSubview(pswdTF)
        
        confirmPswdL = UILabel()
        confirmPswdL.text = "Confirm Password:"
        confirmPswdL.textColor = .gray
        confirmPswdL.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(confirmPswdL)
        
        confirmPswdTF = UITextField()
        confirmPswdTF.attributedPlaceholder =
            NSAttributedString(string: iPswd, attributes: [NSAttributedString.Key.foregroundColor : yellow])
        confirmPswdTF.translatesAutoresizingMaskIntoConstraints = false
        confirmPswdTF.backgroundColor = .gray
        confirmPswdTF.clearsOnBeginEditing = true
        confirmPswdTF.autocapitalizationType = .none
        confirmPswdTF.autocorrectionType = .no
        confirmPswdTF.spellCheckingType = .no
        view.addSubview(confirmPswdTF)
    
        
        
    }
    
    @objc func registrate(){
        if(usernameTF.text?.count == 0 || pswdTF.text?.count == 0 || nameTF.text?.count == 0 || confirmPswdTF.text?.count == 0 || emailTF.text?.count == 0){
            return
        }
        else{
            NetworkManager.postRegister(em: emailTF.text!, ps: pswdTF.text!, us: usernameTF.text!, name: nameTF.text!) {token1 in
                self.thisUserSessionToken = token1
                if(self.pswdTF.text != self.confirmPswdTF.text){
                    let alert = UIAlertController(title: "Alert", message: "Passwords do not match.", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
                if(self.thisUserSessionToken == "failure"){
                    print("cant registrate sry")
                }
                else{
                    print("successfully registered")
                    self.navigationController?.popToRootViewController(animated: true)
                }
            }
        }
        
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            nameTF.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 50),
            nameTF.topAnchor.constraint(equalTo: view.topAnchor, constant: 260),
            nameTF.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -610),
            
            nameL.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: -52),
            nameL.topAnchor.constraint(equalTo: view.topAnchor, constant: 260),
            nameL.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -610),
            
            usernameTF.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 50),
            usernameTF.topAnchor.constraint(equalTo: nameTF.bottomAnchor, constant: 15),
            usernameTF.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -570),
            
            emailTF.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 50),
            emailTF.topAnchor.constraint(equalTo: usernameTF.bottomAnchor, constant: 15),
            emailTF.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -530),
            
            usernameL.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: -70),
            usernameL.topAnchor.constraint(equalTo: nameTF.bottomAnchor, constant: 15),
            usernameL.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -570),
            
            emailL.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: -53),
            emailL.topAnchor.constraint(equalTo: usernameTF.bottomAnchor, constant: 15),
            emailL.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -530),
            
            pswdTF.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 50),
            pswdTF.topAnchor.constraint(equalTo: emailTF.bottomAnchor, constant: 15),
            pswdTF.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -490),
            
            confirmPswdTF.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 50),
            confirmPswdTF.topAnchor.constraint(equalTo: pswdTF.bottomAnchor, constant: 15),
            confirmPswdTF.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -450),
            
            pswdL.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: -70),
            pswdL.topAnchor.constraint(equalTo: emailTF.bottomAnchor, constant: 15),
            pswdL.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -490),
            
            confirmPswdL.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: -100),
            confirmPswdL.topAnchor.constraint(equalTo: pswdTF.bottomAnchor, constant: 15),
            confirmPswdL.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -450),
            
            register.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            register.topAnchor.constraint(equalTo: confirmPswdTF.bottomAnchor, constant: 15),
            register.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -410)
        
            
        ])
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
