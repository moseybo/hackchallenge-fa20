//
//  GameBrowserCell.swift
//  Object Detection V1
//
//  Created by Raleigh Clemens on 12/7/20.
//

import UIKit

class GameBrowserCell: UICollectionViewCell {
    private var title: UILabel!
    
    private var category: UILabel!
    
    private var containerView: UIView!
    
    
    //private var gamePlay: UIImageView!
    
    override init(frame: CGRect){
        super.init(frame: frame)
        
        setUpViews()
        setUpConstraints()
        
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    func setUpViews(){
        containerView = UIView()
        containerView.layer.cornerRadius = 15
        containerView.backgroundColor = UIColor(red: 140/255, green: 140/255, blue: 140/255, alpha: 1)
        containerView.clipsToBounds = true
        containerView.layer.masksToBounds = true
        containerView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(containerView)
        
        title = UILabel()
        title.translatesAutoresizingMaskIntoConstraints = false
        title.textColor = .black
        title.font = title.font.withSize(14)
        title.adjustsFontForContentSizeCategory = true
        containerView.addSubview(title)
        
        category = UILabel()
        category.translatesAutoresizingMaskIntoConstraints = false
        category.textColor = .black
        category.font = category.font.withSize(14)
        //category.font = UIFont.boldSystemFont(ofSize: 12.0)
        containerView.addSubview(category)
    }
        
    
    func setUpConstraints(){
        let containerPadding: CGFloat = 10
        let padding: CGFloat = 50
        let spacing: CGFloat = 10
        
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: containerPadding),
            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: containerPadding),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -containerPadding),
            
            category.topAnchor.constraint(equalTo: containerView.topAnchor, constant: spacing),
            category.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: spacing),
            category.trailingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 100),

            title.topAnchor.constraint(equalTo: containerView.topAnchor, constant: spacing),
            title.leadingAnchor.constraint(equalTo: category.trailingAnchor, constant: spacing),
            //title.trailingAnchor.constraint(equalTo: category.trailingAnchor, constant: 60),
            
            
            
        ])
    }
    
    func configure(game: Game){
        
        title.text = game.title
        category.text = game.category.title + ":"
        
    }
    
//    func configure(game: Game){
//        id.text = game.id
//        title.text = game.title
//        publisher.text = game.publisher
//        price.text = "$" + game.price
//        releaseDate.text = game.release_date
//        platform.text = game.platform
//        category.text = game.category + ":"
//
//        let playerList = game.players
//        players.text = ""
//
//        for player in playerList {
//            players.text! += player + ", "
//        }
//
//        let playersText = players.text!
//        players.text = String(playersText.dropLast())
//
//    }
    
}
