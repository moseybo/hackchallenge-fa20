//
//  HomeViewController.swift
//  Object Detection V1
//
//  Created by Raleigh Clemens on 12/5/20.
//


import UIKit

class HomeViewController: UIViewController {
    
    var forMe: UIButton!
    
    var gameBrowser: UICollectionView!
    var filterBar: UICollectionView!
    let gameBrowserReuseID = "gamecell"
    let filterBarReuseID = "filercell"
    
    var allGames: [Game] = []
    var filters: [Filter] = []
    //var filters = [Filter(title: "Adventure", id: 1), Filter(title: "Strategy", id: 2)]
    //var allGames = [Game(id: "5", title: "Dog", release_date: "1989", publisher: "Nintendo", price: "20", platform: "OS X", category: "Adventure", players: ["A", "B"]), Game(id: "6", title: "Dog", release_date: "1989", publisher: "Nintendo", price: "20", platform: "OS X", category: "Adventure", players: ["A", "B"])]
    //var games = [Game(id: "5", title: "Dog", release_date: "1989", publisher: "Nintendo", price: "20", platform: "OS X", category: "Adventure", players: ["A", "B"]), Game(id: "5", title: "Dog", release_date: "1989", publisher: "Nintendo", price: "20", platform: "OS X", category: "Adventure", players: ["A", "B"])]
    var newGames: [Game] = []
    var selectedFilters: [Filter] = []
    var games: [Game] = []
    
    
    let gamePadding = 12
 
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // getGames() //currently nil since has not been implemented on backend
        title = "Hot Games"
        navigationController?.navigationBar.barTintColor = UIColor(red: 252/255, green: 208/255, blue: 31/255, alpha: 1)
        view.backgroundColor = .black
        getFilters()
        getGames()
        setUpViews()
        setUpConstraints()
        // Do any additional setup after loading the view.
        
    }
    
    override func viewDidAppear(_ animated: Bool){ //should always reload the collection after each update
        getFilters()
        getGames()
        gameBrowser.reloadData()
        filterBar.reloadData()
        
    }
    
    func setUpViews(){
        forMe = UIButton()
        forMe.translatesAutoresizingMaskIntoConstraints = false
        forMe.setTitleColor(.white, for: .normal)
        forMe.layer.cornerRadius = 10
        forMe.setImage(UIImage(named: "pfp"), for: .normal)
        forMe.addTarget(self, action: #selector(forMePage), for: .touchUpInside)
        view.addSubview(forMe)
        
        
        let gameLayout = UICollectionViewFlowLayout()
        gameLayout.minimumLineSpacing = CGFloat(gamePadding)
        gameLayout.scrollDirection = .vertical
        
        gameBrowser = UICollectionView(frame: .zero, collectionViewLayout: gameLayout)
        gameBrowser.translatesAutoresizingMaskIntoConstraints = false
        gameBrowser.backgroundColor = UIColor(red: 69/255, green: 69/255, blue: 69/255, alpha: 1)
        gameBrowser.dataSource = self
        gameBrowser.delegate = self
        gameBrowser.register(GameBrowserCell.self, forCellWithReuseIdentifier: gameBrowserReuseID)
        view.addSubview(gameBrowser)
        
        let filterLayout = UICollectionViewFlowLayout()
        filterLayout.minimumLineSpacing = CGFloat(gamePadding)
        filterLayout.scrollDirection = .horizontal
        
        filterBar = UICollectionView(frame: .zero, collectionViewLayout: filterLayout)
        filterBar.translatesAutoresizingMaskIntoConstraints = false
        filterBar.backgroundColor = UIColor(red: CGFloat(0.524), green: CGFloat(0.4506), blue: CGFloat(0.0247), alpha: 1)
        filterBar.dataSource = self
        filterBar.delegate = self
        filterBar.register(FilterBarCell.self, forCellWithReuseIdentifier: filterBarReuseID)
        view.addSubview(filterBar)
        
    }

    @objc func forMePage(){
        print("go to formepage")
    }
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            
            gameBrowser.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 45),
            gameBrowser.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -35),
            gameBrowser.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            gameBrowser.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            
            filterBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            filterBar.bottomAnchor.constraint(equalTo: gameBrowser.topAnchor, constant: -10),
            filterBar.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            filterBar.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            
            forMe.topAnchor.constraint(equalTo: gameBrowser.bottomAnchor),
            forMe.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            forMe.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 365),
            forMe.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
        ])
        
    }
    
    private func getGames(){
        NetworkManager.getGames{games in
            self.allGames = games
            DispatchQueue.main.async{
                self.gameBrowser.reloadData()
            }
        }

    }
    
    private func getFilters(){
        NetworkManager.getCategories{categories in self.filters = categories
            DispatchQueue.main.async{
                self.filterBar.reloadData()
            }
        }

    }
    
        
}

extension HomeViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        if(collectionView == gameBrowser){
            print(allGames.count)
            return allGames.count
        }
        else{
        return filters.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if(collectionView == gameBrowser){
            let gameCell = collectionView.dequeueReusableCell(withReuseIdentifier: gameBrowserReuseID, for: indexPath) as! GameBrowserCell
            
            gameCell.configure(game: allGames[indexPath.row])
            return gameCell
        }
        
        else{
            let filterCell = collectionView.dequeueReusableCell(withReuseIdentifier: filterBarReuseID, for: indexPath) as! FilterBarCell
            
            filterCell.configure(filter: filters[indexPath.row], filterList: selectedFilters)
            return filterCell
        }
    }
}

extension HomeViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if(collectionView == gameBrowser){
            let size = collectionView.frame.width - CGFloat(gamePadding)
            return CGSize(width: size, height: size/7.5)
        }
        else{
            let size = collectionView.frame.width - CGFloat(gamePadding)
            return CGSize(width: size/4, height: CGFloat(35))
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.allowsMultipleSelection = true
        collectionView.allowsSelection = true
        if(collectionView == gameBrowser){
            let game = allGames[indexPath.row]
            let gameViewController = GameViewController(game: game)
            navigationController?.pushViewController(gameViewController, animated: true)
        }
        else{
            let filter = filters[indexPath.row]
            if(selectedFilters.contains(filter)){
                selectedFilters.removeAll(where: {$0.title == filters[indexPath.row].title})
                getGames()
                gameBrowser.reloadData()
                filterBar.reloadData()
                
            }
            else{
                selectedFilters.append(filter)
                allGames.removeAll(where: {$0.category.title != filters[indexPath.row].title})
                gameBrowser.reloadData()
                filterBar.reloadData()
            }
        }
        
    }
        
    
}
