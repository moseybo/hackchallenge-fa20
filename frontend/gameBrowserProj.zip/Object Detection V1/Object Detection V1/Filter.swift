//
//  Filter.swift
//  Object Detection V1
//
//  Created by Raleigh Clemens on 12/9/20.
//

import Foundation

struct Filter: Codable, Equatable{
    var id: Int
    var title: String
    
    init(title: String, id: Int){
        self.title = title
        self.id = id
        
    }
    
    static func == (lhs: Filter, rhs: Filter) -> Bool{
        return lhs.id == rhs.id && lhs.title == rhs.title
    }
}

struct AllFilters: Codable{
    var data: [Filter]
    
}
