//
//  GameViewController.swift
//  Object Detection V1
//
//  Created by Raleigh Clemens on 12/8/20.
//

import UIKit

class GameViewController: UIViewController {
    
    private var game: Game!
    
    private var id: UILabel!
    private var titleLabel: UILabel!
    private var releaseDate: UILabel!
    private var publisher: UILabel!
    private var platform: UILabel!
    
    private var category: UILabel!
    private var players: UILabel!
    
    private var containerView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //view.backgroundColor = UIColor(red: 255/255, green: 219/255, blue: 219/255, alpha: 1)
        setUpViews()
        setUpConstraints()
        //view.backgroundColor = .white

        // Do any additional setup after loading the view.
    }
    
    init(game: Game){
        super.init(nibName: nil, bundle: nil)
        self.game = game
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUpViews(){
        containerView = UIView(frame: .zero)
        containerView.backgroundColor = UIColor(red: 150/255, green: 150/255, blue: 150/255, alpha: 1)
        containerView.layer.cornerRadius = 8
        containerView.sizeToFit()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(containerView)
        
        id = UILabel()
        id.text = "Game ID: " + String(game.id)
        id.translatesAutoresizingMaskIntoConstraints = false
        id.textColor = .black
        containerView.addSubview(id)
        
        titleLabel = UILabel()
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.text = game.title
        titleLabel.textColor = .black
        containerView.addSubview(titleLabel)
        
        releaseDate = UILabel()
        releaseDate.translatesAutoresizingMaskIntoConstraints = false
        releaseDate.text = "Release Date: " + game.releaseDate
        releaseDate.textColor = .black
        containerView.addSubview(releaseDate)
        
        publisher = UILabel()
        publisher.translatesAutoresizingMaskIntoConstraints = false
        publisher.text = "Developer: " + game.publisher
        publisher.textColor = .black
        containerView.addSubview(publisher)
        
        platform = UILabel()
        platform.translatesAutoresizingMaskIntoConstraints = false
        platform.text = "Supported Platform: " + game.platform
        platform.textColor = .black
        containerView.addSubview(platform)
        
        category = UILabel()
        category.translatesAutoresizingMaskIntoConstraints = false
        category.text = game.category.title
        category.textColor = .black
        //category.font = UIFont.boldSystemFont(ofSize: 12.0)
        containerView.addSubview(category)
        
        players = UILabel()
        players.translatesAutoresizingMaskIntoConstraints = false
        let playerList = game.players
        players.text = "Players: "

        for player in playerList {
            players.text! += player + ", "
        }
        
        var playersText = players.text!
        
        //drops ", " from end of playerList
        playersText = String(playersText.dropLast())
        players.text = String(playersText.dropLast())

        
        players.textColor = .black
        containerView.addSubview(players)
    }
    
    func setUpConstraints(){
        let containerPadding: CGFloat = 10
        let padding: CGFloat = 50
        let spacing: CGFloat = 30
        
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: containerPadding),
            containerView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -containerPadding),
            containerView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: containerPadding),
            containerView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -containerPadding),
            
            
            category.topAnchor.constraint(equalTo: containerView.topAnchor, constant: spacing),
            category.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),

            titleLabel.topAnchor.constraint(equalTo: category.topAnchor, constant: spacing),
            titleLabel.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            
            id.topAnchor.constraint(equalTo: titleLabel.topAnchor, constant: spacing),
            id.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),

            
            releaseDate.topAnchor.constraint(equalTo: id.topAnchor, constant: spacing),
            releaseDate.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            
            publisher.topAnchor.constraint(equalTo: releaseDate.topAnchor, constant: spacing),
            publisher.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),

            platform.topAnchor.constraint(equalTo: publisher.topAnchor, constant: spacing),
            platform.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            
            players.topAnchor.constraint(equalTo: platform.topAnchor, constant: spacing),
            players.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),

            
        
            
            
        ])
    }
    
}
    


