//
//  Game.swift
//  Object Detection V1
//
//  Created by Raleigh Clemens on 12/7/20.
//

import UIKit

struct Game: Codable, Equatable {
    var id: Int
    var title: String
    var platform: String
    var publisher: String
    var releaseDate: String
    var players: [String]
    var category: Filter
    
//    init(id: String, title: String, release_date: String, publisher: String, price: String, platform: String, category: String, players: [String]){
//        self.id = id
//        self.title = title
//        self.release_date = release_date
//        self.publisher = publisher
//        self.price = price
//        self.platform = platform
//        self.category = category
//        self.players = players
//    }

    static func == (lhs: Game, rhs: Game) -> Bool{
        return lhs.id == rhs.id && lhs.title == rhs.title
    }
}


struct AllGames: Codable{
    var success: Bool
    var data: [Game]
}
