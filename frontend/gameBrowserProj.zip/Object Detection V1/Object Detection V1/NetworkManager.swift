//
//  NetworkManager.swift
//  Object Detection V1
//
//  Created by Raleigh Clemens on 12/8/20.
//

import Foundation
import Alamofire

class NetworkManager{
    private static let host = "https://hackchallenge-fa20.herokuapp.com"
    
    static func getGames(completion: @escaping ([Game]) -> Void) {
        let endpoint = "\(host)/api/games/"
        AF.request(endpoint, method: .get).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
                if let gamesData = try? jsonDecoder.decode(AllGames.self, from: data) {
                    //print("got games!")
                    let games = gamesData.data
                    completion(games)
                }
            case .failure(let error):
                //print("failed to get games")
                print(error.localizedDescription)
            }
        }
    }
    
    static func getCategories(completion: @escaping ([Filter]) -> Void) {
        let endpoint = "\(host)/api/categories/"
        AF.request(endpoint, method: .get).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                //print("SUCCESS2")
                jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
                if let categoriesData = try? jsonDecoder.decode(AllFilters.self, from: data) {
                    let categories = categoriesData.data
                    //print("SUCCESS")
                    completion(categories)
                }
            case .failure(let error):
                //print("ERROR")
                print(error.localizedDescription)
            }
        }
    }
    
    static func postLogin(em: String, ps: String, completion: @escaping (String) -> Void) {
        //let endpoint = "\(host)/api/login/"
        let endpoint = "\(host)/api/login/"
        AF.request(endpoint, method: .post, parameters: ["email": em, "password": ps], encoder: JSONParameterEncoder.default).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
                if let tokenData = try? jsonDecoder.decode(Token.self, from: data) {
                    let token = tokenData.sessionToken
                    completion(token)
                }
            case .failure(let error):
                completion("failure")
                print(error.localizedDescription)
            }
        }
    }
    
    static func postRegister(em: String, ps: String, us: String, name: String, completion: @escaping (String) -> Void) {
        let endpoint = "\(host)/api/register/"
        AF.request(endpoint, method: .post, parameters: ["email": em, "password": ps, "username": us, "name": name], encoder: JSONParameterEncoder.default).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
                if let tokenData = try? jsonDecoder.decode(Token.self, from: data) {
                    let token = tokenData.sessionToken
                    completion(token)
                }
            case .failure(let error):
                completion("failure")
                print(error.localizedDescription)
            }
        }
    }
}
