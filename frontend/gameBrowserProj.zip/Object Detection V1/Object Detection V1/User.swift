//
//  User.swift
//  Object Detection V1
//
//  Created by Raleigh Clemens on 12/14/20.
//

import Foundation

struct User: Codable{
    var email: String
    var password: String
}

struct Token: Codable{
    var sessionToken: String
}
